package com.puntored.movie_store_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieStoreApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
