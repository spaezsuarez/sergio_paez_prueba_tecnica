package com.puntored.movie_store_api.dto.film;

import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

@Data
@ToString
public class FilmUpdateRequestDTO implements Serializable {

    private String title;

    private String description;

    private Integer year;

    private Integer rentalDuration;

    private Double rating;

    private Integer duration;

    private Double rentalPrice;
}
