package com.puntored.movie_store_api.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "Store")
public class StoreEntity {

    @Id
    @GeneratedValue
    @Column(name = "`storeId`")
    private Long storeId;

    @Column(name = "`address`")
    private String address;
}
