package com.puntored.movie_store_api.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "Inventory")
public class InventoryEntity {

    @Id
    @GeneratedValue
    @Column(name = "`inventory_id`")
    private Long inventoryId;

    @Column(name = "`quantity`")
    private Integer quantity;

}
