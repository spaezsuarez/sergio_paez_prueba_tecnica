package com.puntored.movie_store_api.service;


import com.puntored.movie_store_api.dto.category.CategoryResponseDTO;
import com.puntored.movie_store_api.dto.film.FilmResponseDto;
import com.puntored.movie_store_api.entity.CategoryEntity;
import com.puntored.movie_store_api.entity.FilmEntity;
import com.puntored.movie_store_api.repository.CategoryRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Log4j2
public class CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    public List<CategoryResponseDTO> searchAvailableCategories(){
        log.info("Inicia servicio de consulta de peliculas");
        List<CategoryResponseDTO> response = new ArrayList<>();
        try{
            List<CategoryEntity> categories = categoryRepository.findAll();
            if(categories.isEmpty()){
                log.info("NO hay categorias disponibles");
                return null;
            }
            categories.forEach((category) -> {
                var categoryData = CategoryResponseDTO.builder()
                        .name(category.getName())
                        .description(category.getDescription())
                        .build();
                response.add(categoryData);
            });
            log.info("Consulta de categorias exitosa");
            return response;

        }catch(Exception e){
            log.error("Error en la consulta de peliculas: ",e);
        }
        return response;
    }

}
