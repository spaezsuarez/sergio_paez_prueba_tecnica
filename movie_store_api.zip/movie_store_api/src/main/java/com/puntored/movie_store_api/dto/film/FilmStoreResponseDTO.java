package com.puntored.movie_store_api.dto.film;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FilmStoreResponseDTO {
    private String address;
    private Integer quantity;
}
