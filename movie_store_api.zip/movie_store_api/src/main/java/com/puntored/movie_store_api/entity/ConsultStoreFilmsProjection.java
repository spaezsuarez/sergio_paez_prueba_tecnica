package com.puntored.movie_store_api.entity;

public interface ConsultStoreFilmsProjection {

    String getaddress();

    Integer getquantity();

}
