package com.puntored.movie_store_api.dto.film;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

@Data
@ToString
public class FilmCreationRequestDTO implements Serializable {

    @NotBlank
    private String title;

    @NotBlank
    private String description;

    @Positive
    private Integer year;

    @Positive
    private Integer rentalDuration;

    @PositiveOrZero
    private Double rating;

    @Positive
    private Integer duration;

    @Positive
    private Double rentalPrice;
}
