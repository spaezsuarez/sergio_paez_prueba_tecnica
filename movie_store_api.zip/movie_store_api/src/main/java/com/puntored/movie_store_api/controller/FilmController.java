package com.puntored.movie_store_api.controller;

import com.puntored.movie_store_api.dto.GeneralResponseDto;
import com.puntored.movie_store_api.dto.film.FilmCreationRequestDTO;
import com.puntored.movie_store_api.dto.film.FilmResponseDto;
import com.puntored.movie_store_api.dto.film.FilmUpdateRequestDTO;
import com.puntored.movie_store_api.service.FilmService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/film")
public class FilmController {

    @Autowired
    private FilmService filmService;

    @GetMapping(produces = {"application/json"})
    public ResponseEntity<List<FilmResponseDto>> searchAllMovies() {
        List<FilmResponseDto> response = filmService.searchAllMovies();
        if (Objects.isNull(response)) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping(produces = {"application/json"})
    public ResponseEntity<GeneralResponseDto> searchAllMovies(@Valid @RequestBody FilmCreationRequestDTO request, BindingResult result) {
        if (result.hasErrors()) {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(filmService.createFilm(request), HttpStatus.OK);
    }

    @PutMapping(value = "/{filmId}", produces = {"application/json"})
    public ResponseEntity<GeneralResponseDto> updateMovie(@PathVariable Long filmId, @RequestBody FilmUpdateRequestDTO request, BindingResult result) {
        return new ResponseEntity<>(filmService.updateFilm(request, filmId), HttpStatus.OK);
    }
}
