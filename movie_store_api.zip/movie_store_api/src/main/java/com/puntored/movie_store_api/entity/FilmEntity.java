package com.puntored.movie_store_api.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "Film")
public class FilmEntity {

    @Id
    @GeneratedValue
    @Column(name = "`film_id`")
    private Long filmId;

    @Column(name = "`title`")
    private String title;

    @Column(name = "`description`")
    private String description;

    @Column(name = "`year`")
    private Integer year;

    @Column(name = "`rental_duration`")
    private Integer rentalDuration;

    @Column(name = "`rating`")
    private Double rating;

    @Column(name = "`duration`")
    private Integer duration;

    @Column(name = "`rental_price`")
    private Double rentalPrice;

}
