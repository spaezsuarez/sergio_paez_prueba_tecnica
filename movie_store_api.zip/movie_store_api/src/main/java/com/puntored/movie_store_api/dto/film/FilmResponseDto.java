package com.puntored.movie_store_api.dto.film;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FilmResponseDto {

    private String title;
    private String description;
    private Integer year;
    private Integer rentalDuration;
    private Double rating;
    private Integer duration;
    private Double rentalPrice;

}
