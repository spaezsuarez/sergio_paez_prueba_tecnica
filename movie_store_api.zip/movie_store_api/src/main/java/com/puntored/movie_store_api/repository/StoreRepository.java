package com.puntored.movie_store_api.repository;

import com.puntored.movie_store_api.entity.ConsultStoreFilmsProjection;
import com.puntored.movie_store_api.entity.StoreEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StoreRepository extends JpaRepository<StoreEntity,Long> {

    @Query(value = "SELECT address,quantity Film f " +
            "inner join Inventory i on f.film_id = i.film_id"+
            "inner join Store s on i.store_id = s.store_id" +
            "where f.film_id = :filmId",
            nativeQuery = true)
    List<ConsultStoreFilmsProjection> consultStoreByFilm(@Param("filmId") Long filmId);

}
