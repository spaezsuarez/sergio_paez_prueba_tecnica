package com.puntored.movie_store_api.entity;


import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "Category")
public class CategoryEntity {

    @Id
    @GeneratedValue
    @Column(name = "`category_id`")
    private Long categoryId;

    @Column(name = "`name`")
    private String name;

    @Column(name = "`description`")
    private String description;

}
