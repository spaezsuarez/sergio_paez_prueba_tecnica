package com.puntored.movie_store_api.dto.category;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CategoryResponseDTO {

    private String name;
    private String description;

}
