package com.puntored.movie_store_api.dto;

import lombok.Data;

@Data
public class GeneralResponseDto {
    private String message;
}
