package com.puntored.movie_store_api.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "FilmCategory")
public class FilmCategory {

    @Id
    @GeneratedValue
    @Column(name = "`filmcategory_id`")
    private Long filmCategoryId;

    @Column(name = "`category_id`")
    private Long categoryId;

    @Column(name = "`film_id`")
    private Long filmId;
}
