package com.puntored.movie_store_api.service;

import com.puntored.movie_store_api.dto.GeneralResponseDto;
import com.puntored.movie_store_api.dto.film.FilmCreationRequestDTO;
import com.puntored.movie_store_api.dto.film.FilmResponseDto;
import com.puntored.movie_store_api.dto.film.FilmStoreResponseDTO;
import com.puntored.movie_store_api.dto.film.FilmUpdateRequestDTO;
import com.puntored.movie_store_api.entity.ConsultStoreFilmsProjection;
import com.puntored.movie_store_api.entity.FilmEntity;
import com.puntored.movie_store_api.repository.FilmEntityRepository;
import com.puntored.movie_store_api.repository.StoreRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@Log4j2
public class FilmService {

    @Autowired
    private FilmEntityRepository filmEntityRepository;

    @Autowired
    private StoreRepository storeRepository;

    public List<FilmResponseDto> searchAllMovies() {
        log.info("Inicia servicio de consulta de peliculas");
        List<FilmResponseDto> response = new ArrayList<>();
        try {
            List<FilmEntity> filmData = filmEntityRepository.findAll();
            if (filmData.isEmpty()) {
                log.info("NO hay peliculas disponibles");
                return null;
            }
            filmData.forEach((film) -> {
                var filmDataResponse = FilmResponseDto.builder()
                        .title(film.getTitle())
                        .year(film.getYear())
                        .rating(film.getRating())
                        .rentalDuration(film.getRentalDuration())
                        .rentalPrice(film.getRentalPrice())
                        .duration(film.getDuration())
                        .description(film.getDescription())
                        .build();
                response.add(filmDataResponse);
            });
            log.info("Consulta exitosa");
            return response;

        } catch (Exception e) {
            log.error("Error en la consulta de peliculas: ", e);
        }
        return response;
    }

    public GeneralResponseDto createFilm(FilmCreationRequestDTO request) {
        log.info("Inicia servicio de creacion de pelicula {}", request.toString());
        GeneralResponseDto response = new GeneralResponseDto();
        try {
            FilmEntity filmData = new FilmEntity();
            filmData.setTitle(request.getTitle());
            filmData.setYear(request.getYear());
            filmData.setRating(request.getRating());
            filmData.setRentalDuration(request.getRentalDuration());
            filmData.setRentalPrice(request.getRentalPrice());
            filmData.setDuration(request.getDuration());
            filmData.setDescription(request.getDescription());
            filmEntityRepository.save(filmData);
            log.info("Creación de pelicula exitosa");
            response.setMessage("Creación de pelicula exitosa");
            return response;

        } catch (Exception e) {
            log.error("Error en la consulta de peliculas: ", e);
            response.setMessage("Ha ocurrido un error");
        }
        return response;
    }

    public GeneralResponseDto updateFilm(FilmUpdateRequestDTO request, Long filmId) {
        log.info("Inicia servicio de actualización {}", request.toString());
        GeneralResponseDto response = new GeneralResponseDto();
        try {
            Optional<FilmEntity> filmData = filmEntityRepository.findById(filmId);
            if (filmData.isEmpty()) {
                response.setMessage("Pelicula invalida");
                return response;
            }
            FilmEntity film = filmData.get();
            film.setTitle(request.getTitle());
            film.setYear(request.getYear());
            film.setRating(request.getRating());
            film.setRentalDuration(request.getRentalDuration());
            film.setRentalPrice(request.getRentalPrice());
            film.setDuration(request.getDuration());
            film.setDescription(request.getDescription());
            filmEntityRepository.save(film);
            log.info("Pelicula Actualizada");
            response.setMessage("Pelicula Actualizada");
            return response;

        } catch (Exception e) {
            log.error("Error en la consulta de peliculas: ", e);
            response.setMessage("Ha ocurrido un error");
        }
        return response;
    }

    public List<FilmStoreResponseDTO> searchStoresByFilm(Long filmId){
        log.info("Inicia servicio de consulta de tiendas para la pelicula {}",filmId);
        List<FilmStoreResponseDTO> response = new ArrayList<>();
        try {
            List<ConsultStoreFilmsProjection> consultStoreFilmsProjections = storeRepository.consultStoreByFilm(filmId);
            if (consultStoreFilmsProjections.isEmpty()) {
                log.info("No hay tiendas disponibles");
                return null;
            }
            consultStoreFilmsProjections.forEach((store) -> {
                var storeData = FilmStoreResponseDTO.builder()
                        .address(store.getaddress())
                        .quantity(store.getquantity())
                        .build();
                response.add(storeData);
            });
            log.info("Consulta de tiendas exitosa");
            return response;

        } catch (Exception e) {
            log.error("Error en la consulta de tiendas: ", e);
        }
        return response;
    }


}
