-- Creación de la tabla Category
CREATE TABLE Category (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    description VARCHAR(255)
);

-- Creación de la tabla Film
CREATE TABLE Film (
    film_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255),
    description VARCHAR(255),
    `year` INT,
    rental_duration INT,
    rating DECIMAL(3,1),
    duration INT,
    rental_price INT
);

-- Creación de la tabla FilmCategory
CREATE TABLE FilmCategory (
    filmcategory_id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT,
    film_id INT,
    FOREIGN KEY (category_id) REFERENCES Category(category_id),
    FOREIGN KEY (film_id) REFERENCES Film(film_id)
);

-- Creación de la tabla Store
CREATE TABLE Store (
    store_id INT AUTO_INCREMENT PRIMARY KEY,
    address VARCHAR(255)
);

-- Creación de la tabla Inventory
CREATE TABLE Inventory (
    inventory_id INT AUTO_INCREMENT PRIMARY KEY,
    film_id INT,
    store_id INT,
    quantity INT,
    FOREIGN KEY (film_id) REFERENCES Film(film_id),
    FOREIGN KEY (store_id) REFERENCES Store(store_id)
);
