INSERT INTO Category (category_id,name,description) VALUES (1, 'Accion','Descripcion 1');
INSERT INTO Film (film_id, title,description,`year`,rental_duration,rating,duration,rental_price) VALUES (1, 'Pelicula 1','Descripcion 1',1900,1500,5.5,120,20000);
INSERT INTO FilmCategory (filmcategory_id,category_id,film_id) VALUES (1,1,1);
INSERT INTO Store(store_id,address) VALUES (1,'CRA 120#12C');
INSERT INTO Inventory(inventory_id,film_id,store_id,quantity) VALUES (1,1,1,20);
